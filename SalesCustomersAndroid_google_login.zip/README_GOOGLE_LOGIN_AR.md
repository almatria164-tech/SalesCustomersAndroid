# تسجيل الدخول عبر Firebase وGoogle

تمت إضافة شاشة تسجيل دخول قبل فتح التطبيق القديم، مع:
- تسجيل الدخول بالبريد وكلمة المرور عبر Firebase Authentication.
- إنشاء حساب بالبريد وكلمة المرور.
- زر تسجيل الدخول بحساب Google.

مهم: ملف google-services.json الحالي لا يحتوي OAuth Web Client ID، لذلك يجب تفعيل Google من Firebase Authentication ثم تنزيل google-services.json الجديد ووضعه داخل app/ قبل أن يعمل زر Google.
