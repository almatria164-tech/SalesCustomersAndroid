package com.example.salescustomers;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends Activity {
    private static final int RC_GOOGLE = 1001;
    private FirebaseAuth auth;
    private GoogleSignInClient googleClient;
    private EditText email;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            openApp();
            return;
        }

        buildLoginScreen();
    }

    private void buildLoginScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(48, 60, 48, 40);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("نظام المبيعات والزبائن");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("تسجيل الدخول");
        subtitle.setTextSize(20);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 24, 0, 20);
        root.addView(subtitle, sp);

        email = new EditText(this);
        email.setHint("البريد الإلكتروني");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        root.addView(email, new LinearLayout.LayoutParams(-1, -2));

        password = new EditText(this);
        password.setHint("كلمة المرور");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.setMargins(0, 12, 0, 12);
        root.addView(password, pp);

        Button login = new Button(this);
        login.setText("تسجيل الدخول");
        root.addView(login, new LinearLayout.LayoutParams(-1, -2));
        login.setOnClickListener(v -> signInEmail());

        Button register = new Button(this);
        register.setText("إنشاء حساب جديد");
        root.addView(register, new LinearLayout.LayoutParams(-1, -2));
        register.setOnClickListener(v -> registerEmail());

        Button google = new Button(this);
        google.setText("تسجيل الدخول بحساب Google");
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.setMargins(0, 18, 0, 0);
        root.addView(google, gp);
        google.setOnClickListener(v -> signInGoogle());

        setContentView(root);
    }

    private void signInEmail() {
        String e = email.getText().toString().trim();
        String p = password.getText().toString();
        if (e.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "أدخل البريد وكلمة المرور", Toast.LENGTH_SHORT).show();
            return;
        }
        auth.signInWithEmailAndPassword(e, p).addOnCompleteListener(task -> {
            if (task.isSuccessful()) openApp();
            else Toast.makeText(this, "فشل تسجيل الدخول: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
        });
    }

    private void registerEmail() {
        String e = email.getText().toString().trim();
        String p = password.getText().toString();
        if (e.isEmpty() || p.length() < 6) {
            Toast.makeText(this, "أدخل بريدًا وكلمة مرور من 6 أحرف على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }
        auth.createUserWithEmailAndPassword(e, p).addOnCompleteListener(task -> {
            if (task.isSuccessful()) openApp();
            else Toast.makeText(this, "تعذر إنشاء الحساب: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
        });
    }

    private void signInGoogle() {
        int clientIdRes = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (clientIdRes == 0) {
            Toast.makeText(this, "لم يتم تفعيل Google في Firebase بعد. حدّث google-services.json أولًا.", Toast.LENGTH_LONG).show();
            return;
        }
        String clientId = getString(clientIdRes);
        if (clientId.isEmpty()) {
            Toast.makeText(this, "لم يتم تفعيل Google في Firebase بعد. حدّث google-services.json أولًا.", Toast.LENGTH_LONG).show();
            return;
        }

        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(clientId)
                .requestEmail()
                .build();
        googleClient = GoogleSignIn.getClient(this, options);
        startActivityForResult(googleClient.getSignInIntent(), RC_GOOGLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE || data == null) return;
        try {
            String idToken = GoogleSignIn.getSignedInAccountFromIntent(data)
                    .getResult(ApiException.class).getIdToken();
            AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
            auth.signInWithCredential(credential).addOnCompleteListener(task -> {
                if (task.isSuccessful()) openApp();
                else Toast.makeText(this, "فشل ربط حساب Google مع Firebase", Toast.LENGTH_LONG).show();
            });
        } catch (ApiException e) {
            Toast.makeText(this, "تم إلغاء تسجيل Google أو حدث خطأ", Toast.LENGTH_LONG).show();
        }
    }

    private void openApp() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
